<?php
//000008640000a:3:{i:1;a:2:{s:8:"words_id";s:1:"1";s:5:"words";s:9:"共产党";}i:2;a:2:{s:8:"words_id";s:1:"2";s:5:"words";s:9:"习近平";}i:3;a:2:{s:8:"words_id";s:1:"3";s:5:"words";s:9:"法轮功";}}
?>