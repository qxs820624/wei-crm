<?php
//000000021600a:1:{i:0;a:11:{s:5:"ad_id";s:2:"14";s:7:"site_id";s:1:"2";s:7:"city_id";s:1:"0";s:5:"title";s:6:"美食";s:8:"link_url";s:21:"http://www.sungsw.com";s:5:"photo";s:28:"2015/10/17/562224b766831.png";s:4:"code";s:0:"";s:7:"bg_date";s:10:"2014-11-15";s:8:"end_date";s:10:"2020-01-01";s:6:"closed";s:1:"0";s:7:"orderby";s:1:"3";}}
?>