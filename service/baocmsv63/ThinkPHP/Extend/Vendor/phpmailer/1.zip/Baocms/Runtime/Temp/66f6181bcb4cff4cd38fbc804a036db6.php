<?php
//000000086400a:2:{s:7:"default";a:5:{s:11:"template_id";s:1:"4";s:4:"name";s:12:"默认模版";s:5:"theme";s:7:"default";s:5:"photo";s:9:"index.jpg";s:10:"is_default";s:1:"0";}s:4:"test";a:5:{s:11:"template_id";s:1:"5";s:4:"name";s:12:"测试模板";s:5:"theme";s:4:"test";s:5:"photo";s:9:"index.jpg";s:10:"is_default";s:1:"1";}}
?>