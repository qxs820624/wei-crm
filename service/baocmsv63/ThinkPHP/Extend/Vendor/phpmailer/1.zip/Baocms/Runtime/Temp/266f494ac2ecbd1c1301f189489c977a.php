<?php
//000000000600a:6:{s:4:"shop";s:3:"122";s:6:"coupon";s:2:"84";s:5:"users";s:2:"19";s:4:"life";s:1:"9";s:4:"post";s:1:"0";s:9:"community";s:1:"6";}
?>