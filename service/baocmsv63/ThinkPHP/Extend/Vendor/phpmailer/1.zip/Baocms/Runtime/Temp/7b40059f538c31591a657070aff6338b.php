<?php
//000000021600a:1:{i:0;a:11:{s:5:"ad_id";s:2:"35";s:7:"site_id";s:2:"15";s:7:"city_id";s:1:"1";s:5:"title";s:21:"文章资讯列表页";s:8:"link_url";s:28:"/shop/detail/shop_id/49.html";s:5:"photo";s:28:"2015/04/23/5538c5b08e194.jpg";s:4:"code";s:21:"文章资讯列表页";s:7:"bg_date";s:10:"2015-01-06";s:8:"end_date";s:10:"2020-01-01";s:6:"closed";s:1:"0";s:7:"orderby";s:1:"1";}}
?>