<?php
//000000043200a:1:{i:0;a:11:{s:5:"ad_id";s:2:"50";s:7:"site_id";s:2:"20";s:7:"city_id";s:1:"1";s:5:"title";s:21:"右侧二维码图片";s:8:"link_url";s:1:"#";s:5:"photo";s:28:"2015/04/24/5539dd54ed0b5.jpg";s:4:"code";s:0:"";s:7:"bg_date";s:10:"2015-01-13";s:8:"end_date";s:10:"2020-01-01";s:6:"closed";s:1:"0";s:7:"orderby";s:1:"1";}}
?>